package internship.task40;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task40Application {

	public static void main(String[] args) {
		SpringApplication.run(Task40Application.class, args);
	}

}
