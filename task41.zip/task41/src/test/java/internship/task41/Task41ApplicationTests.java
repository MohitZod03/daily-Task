package internship.task41;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task41ApplicationTests {

	@Test
	void contextLoads() {
	}

}
